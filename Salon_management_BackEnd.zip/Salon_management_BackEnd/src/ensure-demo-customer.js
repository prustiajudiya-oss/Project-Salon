const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./models/User');

dotenv.config();

async function ensureDemoCustomer() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/salon_management');

  const email = 'alex@example.com';
  let customer = await User.findOne({ email }).select('+password');

  if (!customer) {
    customer = new User({
      name: 'Alex Mercer',
      email,
      password: 'customer123',
      role: 'Customer',
      phone: '9876543215',
    });
  } else {
    customer.password = 'customer123';
    customer.role = 'Customer';
    customer.isActive = true;
  }

  await customer.save();
  console.log('Demo customer account is ready: alex@example.com / customer123');
  await mongoose.disconnect();
}

ensureDemoCustomer().catch(async (error) => {
  console.error('Could not set up demo customer:', error.message);
  await mongoose.disconnect();
  process.exit(1);
});
