const DEFAULT_WORKING_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const weekdayFromDateString = (dateStr) => {
  const [year, month, day] = String(dateStr || '').split('-').map(Number);
  if (!year || !month || !day) return '';
  return new Date(year, month - 1, day).toLocaleDateString('en-US', { weekday: 'long' });
};

const effectiveWorkingDays = (workingDays) => {
  if (Array.isArray(workingDays) && workingDays.length > 0) {
    return workingDays;
  }
  return DEFAULT_WORKING_DAYS;
};

module.exports = { DEFAULT_WORKING_DAYS, weekdayFromDateString, effectiveWorkingDays };
