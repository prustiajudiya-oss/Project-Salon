const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./models/User');

dotenv.config();

async function ensureDemoBarber() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/salon_management');

  const email = 'david@salon.com';
  let barber = await User.findOne({ email }).select('+password');

  if (!barber) {
    barber = new User({
      name: 'David Park',
      email,
      password: 'barber123',
      role: 'Barber',
      phone: '9876543213',
      specializations: ['Beard Styling', 'Haircut', 'Massage'],
      workingHours: { start: '09:00', end: '17:00' },
      workingDays: ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
      commissionRate: 35,
    });
  } else {
    barber.password = 'barber123';
    barber.role = 'Barber';
    barber.isActive = true;
  }

  await barber.save();
  console.log('Demo barber account is ready: david@salon.com / barber123');
  await mongoose.disconnect();
}

ensureDemoBarber().catch(async (error) => {
  console.error('Could not set up demo barber:', error.message);
  await mongoose.disconnect();
  process.exit(1);
});
