const Appointment = require('../models/Appointment');
const Order = require('../models/Order');
const User = require('../models/User');
const Service = require('../models/Service');
const Wage = require('../models/Wage');
const Inventory = require('../models/Inventory');
const TimeOff = require('../models/TimeOff');

const todayString = () => new Date().toISOString().split('T')[0];

const monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const getAdminDashboard = async (req, res) => {
  try {
    const today = todayString();

    const [
      totalCustomers,
      totalBarbers,
      totalReceptionists,
      activeServices,
      totalAppointments,
      todayAppointmentsCount,
      pendingAppointmentsCount,
      completedRevenue,
      activeOrders,
      lowStockCount,
      todayAppointments,
      pendingAppointments,
      recentOrders,
      lowStockItems,
      recentCustomers,
      topServices,
      staffPerformance,
      completedOrderRevenue,
    ] = await Promise.all([
      User.countDocuments({ role: 'Customer' }),
      User.countDocuments({ role: 'Barber', isActive: true }),
      User.countDocuments({ role: 'Receptionist', isActive: true }),
      Service.countDocuments({ isActive: true }),
      Appointment.countDocuments(),
      Appointment.countDocuments({ date: today }),
      Appointment.countDocuments({ status: 'Pending' }),
      Appointment.aggregate([
        { $match: { status: 'Completed' } },
        { $group: { _id: null, total: { $sum: '$totalAmount' } } },
      ]),
      Order.countDocuments({ status: { $nin: ['Cancelled', 'Delivered'] } }),
      Inventory.countDocuments({ isLowStock: true }),
      Appointment.find({ date: today })
        .populate('customer', 'name phone')
        .populate('barber', 'name')
        .populate('service', 'name duration price')
        .sort({ timeSlot: 1 })
        .limit(20),
      Appointment.find({ status: 'Pending' })
        .populate('customer', 'name phone')
        .populate('barber', 'name')
        .populate('service', 'name duration')
        .sort({ date: 1, timeSlot: 1 })
        .limit(10),
      Order.find({ status: { $ne: 'Cancelled' } })
        .populate('customer', 'name email phone')
        .sort({ createdAt: -1 })
        .limit(10),
      Inventory.find({ isLowStock: true })
        .select('itemName category currentStock minimumStock unit supplier')
        .sort({ currentStock: 1 })
        .limit(10),
      User.find({ role: 'Customer' })
        .select('name email phone createdAt')
        .sort({ createdAt: -1 })
        .limit(10),
      Appointment.aggregate([
        { $match: { status: 'Completed' } },
        { $group: { _id: '$service', bookings: { $sum: 1 }, revenue: { $sum: '$totalAmount' } } },
        { $sort: { bookings: -1 } },
        { $limit: 5 },
        { $lookup: { from: 'services', localField: '_id', foreignField: '_id', as: 'service' } },
        { $unwind: '$service' },
        { $project: { _id: 0, serviceId: '$_id', name: '$service.name', category: '$service.category', bookings: 1, revenue: 1 } },
      ]),
      Appointment.aggregate([
        { $match: { status: 'Completed' } },
        { $group: { _id: '$barber', completedAppointments: { $sum: 1 }, revenue: { $sum: '$totalAmount' } } },
        { $sort: { revenue: -1 } },
        { $limit: 5 },
        { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'barber' } },
        { $unwind: '$barber' },
        { $project: { _id: 0, barberId: '$_id', name: '$barber.name', completedAppointments: 1, revenue: 1, commissionRate: '$barber.commissionRate' } },
      ]),
      Order.aggregate([
        { $match: { status: { $ne: 'Cancelled' }, paymentStatus: 'Completed' } },
        { $group: { _id: null, total: { $sum: '$totalAmount' } } },
      ]),
    ]);

    res.json({
      success: true,
      data: {
        overview: {
          totalCustomers, totalBarbers, totalReceptionists, activeServices,
          totalAppointments, todayAppointments: todayAppointmentsCount,
          pendingAppointments: pendingAppointmentsCount,
          appointmentRevenue: completedRevenue[0]?.total || 0,
          productRevenue: completedOrderRevenue[0]?.total || 0,
          totalRevenue: (completedRevenue[0]?.total || 0) + (completedOrderRevenue[0]?.total || 0),
          activeOrders, lowStockCount,
        },
        todayAppointments, pendingAppointments, recentOrders, lowStockItems,
        recentCustomers, topServices, staffPerformance,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getCustomerDashboard = async (req, res) => {
  try {
    const customerId = req.user._id;
    const today = todayString();

    const [upcomingAppointments, pastAppointments, recentOrders, appointmentSpend, purchaseSpend, totalAppointments, profile, browseServices] = await Promise.all([
      Appointment.find({
        customer: customerId,
        date: { $gte: today },
        status: { $nin: ['Cancelled', 'Completed'] },
      })
        .populate('barber', 'name avatar')
        .populate('service', 'name price duration category')
        .sort({ date: 1, timeSlot: 1 })
        .limit(5),

      Appointment.find({
        customer: customerId,
        status: 'Completed',
      })
        .populate('barber', 'name')
        .populate('service', 'name price category')
        .sort({ date: -1 })
        .limit(10),

      Order.find({ customer: customerId })
        .sort({ createdAt: -1 })
        .limit(5),

      Appointment.aggregate([
        { $match: { customer: customerId, status: 'Completed' } },
        { $group: { _id: null, total: { $sum: '$totalAmount' } } },
      ]),
      Order.aggregate([
        { $match: { customer: customerId, status: { $ne: 'Cancelled' }, paymentStatus: 'Completed' } },
        { $group: { _id: null, total: { $sum: '$totalAmount' } } },
      ]),
      Appointment.countDocuments({ customer: customerId }),
      User.findById(customerId).select('name email phone avatar address createdAt'),
      Service.find({ isActive: true }).select('name category price duration image description').sort({ category: 1, name: 1 }).limit(6),
    ]);

    // Favorite services (most booked)
    const favoriteServices = await Appointment.aggregate([
      { $match: { customer: customerId, status: 'Completed' } },
      { $group: { _id: '$service', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 3 },
      {
        $lookup: {
          from: 'services',
          localField: '_id',
          foreignField: '_id',
          as: 'serviceInfo',
        },
      },
      { $unwind: '$serviceInfo' },
      {
        $project: {
          name: '$serviceInfo.name',
          category: '$serviceInfo.category',
          price: '$serviceInfo.price',
          bookings: '$count',
        },
      },
    ]);

    res.json({
      success: true,
      data: {
        profile,
        upcomingAppointments,
        nextAppointment: upcomingAppointments[0] || null,
        pastAppointments,
        appointmentHistory: pastAppointments,
        recentOrders,
        favoriteServices,
        browseServices,
        appointmentSpend: appointmentSpend[0]?.total || 0,
        purchaseSpend: purchaseSpend[0]?.total || 0,
        totalSpent: (appointmentSpend[0]?.total || 0) + (purchaseSpend[0]?.total || 0),
        totalAppointments,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getBarberDashboard = async (req, res) => {
  try {
    const barberId = req.user._id;
    const today = todayString();
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    const [todayAppointments, upcomingAppointments, monthlyEarnings, totalEarnings, todayEarnings, earningsByMonth, timeOffRequests] = await Promise.all([
      Appointment.find({
        barber: barberId,
        date: today,
        status: { $nin: ['Cancelled'] },
      })
        .populate('customer', 'name phone')
        .populate('service', 'name duration price')
        .sort({ timeSlot: 1 }),

      Appointment.find({
        barber: barberId,
        date: { $gt: today },
        status: { $nin: ['Cancelled'] },
      })
        .populate('customer', 'name')
        .populate('service', 'name price')
        .sort({ date: 1, timeSlot: 1 })
        .limit(10),

      Wage.aggregate([
        { $match: { barber: barberId, month: currentMonth, year: currentYear } },
        {
          $group: {
            _id: null,
            totalEarnings: { $sum: '$totalEarning' },
            totalCommission: { $sum: '$commissionEarned' },
            servicesCompleted: { $sum: 1 },
          },
        },
      ]),

      Wage.aggregate([
        { $match: { barber: barberId } },
        { $group: { _id: null, totalEarnings: { $sum: '$totalEarning' }, totalCommission: { $sum: '$commissionEarned' }, servicesCompleted: { $sum: 1 } } },
      ]),
      Wage.aggregate([
        { $match: { barber: barberId, date: today } },
        { $group: { _id: null, totalEarnings: { $sum: '$totalEarning' }, totalCommission: { $sum: '$commissionEarned' }, servicesCompleted: { $sum: 1 } } },
      ]),
      Wage.aggregate([
        { $match: { barber: barberId, year: currentYear } },
        { $group: { _id: '$month', totalEarnings: { $sum: '$totalEarning' }, totalCommission: { $sum: '$commissionEarned' }, servicesCompleted: { $sum: 1 } } },
      ]),
      TimeOff.find({ barber: barberId }).sort({ startDate: -1 }).limit(10),
    ]);

    res.json({
      success: true,
      data: {
        todayAppointments,
        upcomingAppointments,
        monthlyEarnings: monthlyEarnings[0] || { totalEarnings: 0, totalCommission: 0, servicesCompleted: 0 },
        todayEarnings: todayEarnings[0] || { totalEarnings: 0, totalCommission: 0, servicesCompleted: 0 },
        totalEarnings: totalEarnings[0] || { totalEarnings: 0, totalCommission: 0, servicesCompleted: 0 },
        earningsOverview: monthLabels.map((month, index) => {
          const entry = earningsByMonth.find(item => item._id === index + 1);
          return { month, totalEarnings: entry?.totalEarnings || 0, totalCommission: entry?.totalCommission || 0, servicesCompleted: entry?.servicesCompleted || 0 };
        }),
        workingSchedule: { workingHours: req.user.workingHours, workingDays: req.user.workingDays },
        timeOffRequests,
        statusCounts: todayAppointments.reduce((counts, appointment) => {
          counts[appointment.status] = (counts[appointment.status] || 0) + 1;
          return counts;
        }, {}),
        commissionRate: req.user.commissionRate,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getReceptionistDashboard = async (req, res) => {
  try {
    const today = todayString();

    const [todayAppointments, pendingAppointments, availableBarbers, recentCustomers, calendarAppointments, statusSummary] = await Promise.all([
      Appointment.find({ date: today })
        .populate('customer', 'name phone')
        .populate('barber', 'name')
        .populate('service', 'name duration')
        .sort({ timeSlot: 1 }),

      Appointment.find({ status: 'Pending' })
        .populate('customer', 'name phone')
        .populate('barber', 'name')
        .populate('service', 'name')
        .sort({ date: 1 })
        .limit(10),

      User.find({ role: 'Barber', isActive: true }).select('name specializations workingHours'),

      User.find({ role: 'Customer' })
        .select('name email phone')
        .sort({ createdAt: -1 })
        .limit(10),
      Appointment.find({ date: { $gte: today } })
        .populate('customer', 'name phone')
        .populate('barber', 'name')
        .populate('service', 'name duration')
        .sort({ date: 1, timeSlot: 1 })
        .limit(100),
      Appointment.aggregate([
        { $match: { date: today } },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
    ]);

    res.json({
      success: true,
      data: {
        todayAppointments,
        pendingAppointments,
        availableBarbers,
        recentCustomers,
        masterBookingCalendar: calendarAppointments,
        appointmentStatusSummary: statusSummary.reduce((summary, entry) => {
          summary[entry._id] = entry.count;
          return summary;
        }, { Pending: 0, Confirmed: 0, 'In Progress': 0, Completed: 0, Cancelled: 0 }),
        todayCount: todayAppointments.length,
        pendingCount: pendingAppointments.length,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getAdminDashboard, getCustomerDashboard, getBarberDashboard, getReceptionistDashboard };
