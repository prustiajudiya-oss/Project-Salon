const mongoose = require('mongoose');
const Appointment = require('../models/Appointment');
const Service = require('../models/Service');
const User = require('../models/User');
const TimeOff = require('../models/TimeOff');
const { weekdayFromDateString, effectiveWorkingDays } = require('../utils/date');

const createAppointment = async (req, res) => {
  try {
    const { service, barber, date, timeSlot, notes, customerId } = req.body;
    let customer = req.user.role === 'Customer' ? req.user._id : customerId;

    if (!customer) {
      customer = req.user._id;
    }

    if (req.user.role !== 'Customer' && customerId) {
      const customerDoc = await User.findById(customer);
      if (!customerDoc) {
        customer = req.user._id;
      }
    }

    // 1. Resolve Service (by ID, by Name, or fallback)
    let serviceDoc = null;
    if (service && mongoose.Types.ObjectId.isValid(service)) {
      serviceDoc = await Service.findById(service);
    }
    if (!serviceDoc && service) {
      serviceDoc = await Service.findOne({ name: new RegExp('^' + service + '$', 'i') });
    }
    if (!serviceDoc && service) {
      serviceDoc = await Service.findOne({ name: new RegExp(service, 'i') });
    }
    if (!serviceDoc) {
      serviceDoc = await Service.findOne({ isActive: true });
    }
    if (!serviceDoc) {
      serviceDoc = await Service.create({
        name: typeof service === 'string' && service ? service : 'Hair Style',
        category: 'Hair',
        price: 500,
        duration: 30,
        isActive: true,
      });
    }

    // 2. Resolve Barber (by ID, by Name, or fallback)
    let barberDoc = null;
    if (barber && mongoose.Types.ObjectId.isValid(barber)) {
      barberDoc = await User.findById(barber);
    }
    if (!barberDoc && barber) {
      barberDoc = await User.findOne({ name: new RegExp(barber, 'i'), role: 'Barber' });
    }
    if (!barberDoc && barber) {
      barberDoc = await User.findOne({ name: new RegExp('^' + barber + '$', 'i') });
    }
    if (!barberDoc) {
      barberDoc = await User.findOne({ role: 'Barber' });
    }
    if (!barberDoc) {
      barberDoc = await User.create({
        name: typeof barber === 'string' && barber ? barber : 'Master Stylist',
        email: `barber_${Date.now()}@salon.com`,
        password: 'password123',
        role: 'Barber',
      });
    }

    const actualServiceId = serviceDoc._id;
    const actualBarberId = barberDoc._id;

    // Check for scheduling conflicts
    const existingAppointment = await Appointment.findOne({
      barber: actualBarberId,
      date,
      timeSlot,
      status: { $nin: ['Cancelled'] },
    });

    if (existingAppointment) {
      return res.status(400).json({ success: false, message: 'This time slot is already booked for this barber' });
    }

    // Check barber time off
    const timeOff = await TimeOff.findOne({
      barber: actualBarberId,
      startDate: { $lte: date },
      endDate: { $gte: date },
      status: 'Approved',
    });

    if (timeOff) {
      return res.status(400).json({ success: false, message: 'Barber is on leave on this date' });
    }

    // Calculate end time
    const [hours, minutes] = (timeSlot || "10:00").split(':').map(Number);
    const validHours = isNaN(hours) ? 10 : hours;
    const validMinutes = isNaN(minutes) ? 0 : minutes;
    const endMinutes = validHours * 60 + validMinutes + (serviceDoc.duration || 30);
    const endTime = `${String(Math.floor(endMinutes / 60)).padStart(2, '0')}:${String(endMinutes % 60).padStart(2, '0')}`;

    const appointment = await Appointment.create({
      customer,
      service: actualServiceId,
      barber: actualBarberId,
      date: date || new Date().toISOString().split("T")[0],
      timeSlot: timeSlot || "10:00 AM",
      endTime,
      notes: notes || `Service: ${serviceDoc.name}`,
      totalAmount: serviceDoc.price || 500,
    });

    const populated = await Appointment.findById(appointment._id)
      .populate('customer', 'name email phone')
      .populate('barber', 'name specializations')
      .populate('service', 'name price duration category');

    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAllAppointments = async (req, res) => {
  try {
    const { status, date, barber, customer, page = 1, limit = 20 } = req.query;
    const query = {};

    if (status) query.status = status;
    if (date) query.date = date;
    if (barber) query.barber = barber;
    if (customer) query.customer = customer;

    const total = await Appointment.countDocuments(query);
    const appointments = await Appointment.find(query)
      .populate('customer', 'name email phone')
      .populate('barber', 'name specializations')
      .populate('service', 'name price duration category')
      .sort({ date: -1, timeSlot: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({
      success: true,
      data: appointments,
      pagination: { total, page: Number(page), pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getMyAppointments = async (req, res) => {
  try {
    const { status, upcoming } = req.query;
    const query = { customer: req.user._id };

    if (status) query.status = status;
    if (upcoming === 'true') {
      const today = new Date().toISOString().split('T')[0];
      query.date = { $gte: today };
      query.status = { $nin: ['Cancelled', 'Completed'] };
    }

    const appointments = await Appointment.find(query)
      .populate('barber', 'name specializations avatar')
      .populate('service', 'name price duration category')
      .sort({ date: -1, timeSlot: -1 });

    res.json({ success: true, data: appointments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getBarberAppointments = async (req, res) => {
  try {
    const { status, date } = req.query;
    const query = { barber: req.user._id };

    if (status) query.status = status;
    if (date) query.date = date;

    const appointments = await Appointment.find(query)
      .populate('customer', 'name email phone')
      .populate('service', 'name price duration category')
      .sort({ date: 1, timeSlot: 1 });

    res.json({ success: true, data: appointments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAppointmentById = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id)
      .populate('customer', 'name email phone')
      .populate('barber', 'name specializations avatar')
      .populate('service', 'name price duration category');

    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }

    const userId = req.user._id.toString();
    const isOwner = appointment.customer._id.toString() === userId || appointment.barber._id.toString() === userId;
    if (!isOwner && !['Admin', 'Receptionist'].includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Not authorized to view this appointment' });
    }

    res.json({ success: true, data: appointment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateAppointmentStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ['Pending', 'Confirmed', 'In Progress', 'Completed', 'Cancelled'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    const existingAppointment = await Appointment.findById(req.params.id);
    if (!existingAppointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }

    if (req.user.role === 'Barber' && existingAppointment.barber.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized to update this appointment' });
    }

    const appointment = await Appointment.findByIdAndUpdate(req.params.id, { status }, { new: true })
      .populate('customer', 'name email phone')
      .populate('barber', 'name specializations')
      .populate('service', 'name price duration category');

    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }

    res.json({ success: true, data: appointment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const cancelAppointment = async (req, res) => {
  try {
    const { reason } = req.body;
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }

    if (appointment.customer.toString() !== req.user._id.toString() &&
        !['Admin', 'Receptionist'].includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Not authorized to cancel this appointment' });
    }

    appointment.status = 'Cancelled';
    appointment.cancellationReason = reason || '';
    await appointment.save();

    res.json({ success: true, data: appointment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const rescheduleAppointment = async (req, res) => {
  try {
    const { date, timeSlot } = req.body;
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }

    if (appointment.customer.toString() !== req.user._id.toString() &&
        !['Admin', 'Receptionist'].includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Not authorized to reschedule this appointment' });
    }

    // Check conflicts on new date/time
    const conflict = await Appointment.findOne({
      barber: appointment.barber,
      date,
      timeSlot,
      status: { $nin: ['Cancelled'] },
      _id: { $ne: appointment._id },
    });

    if (conflict) {
      return res.status(400).json({ success: false, message: 'New time slot is already booked' });
    }

    appointment.date = date;
    appointment.timeSlot = timeSlot;
    appointment.status = 'Pending';
    await appointment.save();

    const populated = await Appointment.findById(appointment._id)
      .populate('customer', 'name email phone')
      .populate('barber', 'name specializations')
      .populate('service', 'name price duration category');

    res.json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAvailableSlots = async (req, res) => {
  try {
    const { barberId, date } = req.query;

    if (!barberId || !date) {
      return res.status(400).json({ success: false, message: 'Barber ID and date are required' });
    }

    const barber = await User.findById(barberId);
    if (!barber || barber.role !== 'Barber') {
      return res.status(404).json({ success: false, message: 'Barber not found' });
    }

    // Check if barber is on leave
    const timeOff = await TimeOff.findOne({
      barber: barberId,
      startDate: { $lte: date },
      endDate: { $gte: date },
      status: 'Approved',
    });

    if (timeOff) {
      return res.json({ success: true, data: [], message: 'Barber is on leave' });
    }

    // Check if the selected day is a working day
    const dayOfWeek = weekdayFromDateString(date);
    const workingDays = effectiveWorkingDays(barber.workingDays);
    if (workingDays.length > 0 && !workingDays.includes(dayOfWeek)) {
      return res.json({ success: true, data: [], message: 'Barber does not work on this day' });
    }

    // Generate all possible slots (30 min intervals)
    const startHour = parseInt(barber.workingHours.start.split(':')[0]);
    const endHour = parseInt(barber.workingHours.end.split(':')[0]);
    const allSlots = [];

    for (let h = startHour; h < endHour; h++) {
      allSlots.push(`${String(h).padStart(2, '0')}:00`);
      allSlots.push(`${String(h).padStart(2, '0')}:30`);
    }

    // Get booked slots for this barber on this date
    const bookedAppointments = await Appointment.find({
      barber: barberId,
      date,
      status: { $nin: ['Cancelled'] },
    }).select('timeSlot endTime');

    const bookedSlots = bookedAppointments.map(a => a.timeSlot);

    const availableSlots = allSlots.map(slot => ({
      time: slot,
      available: !bookedSlots.includes(slot),
    }));

    res.json({ success: true, data: availableSlots });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const assignBarber = async (req, res) => {
  try {
    const { barberId } = req.body;

    const barber = await User.findById(barberId);
    if (!barber || barber.role !== 'Barber') {
      return res.status(404).json({ success: false, message: 'Barber not found' });
    }

    const appointment = await Appointment.findByIdAndUpdate(
      req.params.id,
      { barber: barberId, assignedBy: req.user._id },
      { new: true }
    )
      .populate('customer', 'name email phone')
      .populate('barber', 'name specializations')
      .populate('service', 'name price duration category');

    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }

    res.json({ success: true, data: appointment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const deleteAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findByIdAndDelete(req.params.id);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found' });
    }
    res.json({ success: true, message: 'Appointment deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createAppointment,
  getAllAppointments,
  getMyAppointments,
  getBarberAppointments,
  getAppointmentById,
  updateAppointmentStatus,
  cancelAppointment,
  rescheduleAppointment,
  getAvailableSlots,
  assignBarber,
  deleteAppointment,
};
