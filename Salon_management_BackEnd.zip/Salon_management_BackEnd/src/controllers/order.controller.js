const Order = require('../models/Order');
const Product = require('../models/Product');

const TAX_RATE = 0.08; // 8% tax

const createOrder = async (req, res) => {
  try {
    const { items, shippingAddress, paymentMethod } = req.body;

    // Validate products and calculate totals
    const orderItems = [];
    let subtotal = 0;

    for (const item of items) {
      const product = await Product.findById(item.product);
      if (!product) {
        return res.status(404).json({ success: false, message: `Product not found: ${item.product}` });
      }
      if (product.stockQuantity < item.quantity) {
        return res.status(400).json({ success: false, message: `Insufficient stock for ${product.name}` });
      }

      orderItems.push({
        product: product._id,
        name: product.name,
        price: product.price,
        quantity: item.quantity,
      });

      subtotal += product.price * item.quantity;

      // Reduce stock
      product.stockQuantity -= item.quantity;
      await product.save();
    }

    const tax = Math.round(subtotal * TAX_RATE * 100) / 100;
    const totalAmount = Math.round((subtotal + tax) * 100) / 100;

    const order = await Order.create({
      customer: req.user._id,
      items: orderItems,
      subtotal,
      tax,
      totalAmount,
      shippingAddress,
      paymentMethod: paymentMethod || 'Cash',
    });

    const populated = await Order.findById(order._id)
      .populate('items.product', 'name image')
      .populate('customer', 'name email');

    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getMyOrders = async (req, res) => {
  try {
    const { status } = req.query;
    const query = { customer: req.user._id };
    if (status) query.status = status;

    const orders = await Order.find(query)
      .populate('items.product', 'name image price')
      .sort({ createdAt: -1 });

    res.json({ success: true, data: orders });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAllOrders = async (req, res) => {
  try {
    const { status, paymentStatus, page = 1, limit = 20 } = req.query;
    const query = {};

    if (status) query.status = status;
    if (paymentStatus) query.paymentStatus = paymentStatus;

    const total = await Order.countDocuments(query);
    const orders = await Order.find(query)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name image')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({
      success: true,
      data: orders,
      pagination: { total, page: Number(page), pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name image price');

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    // Only allow owner or admin to view
    if (order.customer._id.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateOrderStatus = async (req, res) => {
  try {
    const { status, paymentStatus } = req.body;
    const update = {};
    if (status) update.status = status;
    if (paymentStatus) update.paymentStatus = paymentStatus;

    const order = await Order.findByIdAndUpdate(req.params.id, update, { new: true })
      .populate('customer', 'name email')
      .populate('items.product', 'name image');

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const cancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    if (order.customer.toString() !== req.user._id.toString() && !['Admin', 'Receptionist'].includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    if (['Shipped', 'Delivered'].includes(order.status)) {
      return res.status(400).json({ success: false, message: 'Cannot cancel a shipped or delivered order' });
    }

    // Restore stock
    for (const item of order.items) {
      await Product.findByIdAndUpdate(item.product, {
        $inc: { stockQuantity: item.quantity },
      });
    }

    order.status = 'Cancelled';
    order.paymentStatus = 'Refunded';
    await order.save();

    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const requestCancelOrder = async (req, res) => {
  try {
    const { reason } = req.body;
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    if (order.customer.toString() !== req.user._id.toString() && !['Admin', 'Receptionist'].includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    if (['Shipped', 'Delivered', 'Cancelled'].includes(order.status)) {
      return res.status(400).json({ success: false, message: `Cannot cancel an order with status "${order.status}"` });
    }

    order.status = 'Cancel Requested';
    order.cancelRequest = {
      status: 'Pending',
      reason: reason || 'Customer requested cancellation',
      requestedAt: new Date(),
    };

    await order.save();

    const populated = await Order.findById(order._id)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name image price');

    res.json({ success: true, data: populated, message: 'Cancellation request submitted to Admin & Receptionist for approval.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getCancelRequests = async (req, res) => {
  try {
    const orders = await Order.find({
      $or: [
        { status: 'Cancel Requested' },
        { 'cancelRequest.status': 'Pending' }
      ]
    })
      .populate('customer', 'name email phone')
      .populate('items.product', 'name image price')
      .sort({ updatedAt: -1 });

    res.json({ success: true, data: orders });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const approveCancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    if (order.status === 'Cancelled' && order.cancelRequest?.status === 'Approved') {
      return res.status(400).json({ success: false, message: 'Cancellation is already approved.' });
    }

    // Restore stock for items
    for (const item of order.items) {
      if (item.product) {
        await Product.findByIdAndUpdate(item.product, {
          $inc: { stockQuantity: item.quantity },
        });
      }
    }

    order.status = 'Cancelled';
    order.paymentStatus = 'Refunded';
    order.cancelRequest = {
      ...order.cancelRequest,
      status: 'Approved',
      reviewedBy: req.user._id,
      reviewedAt: new Date(),
    };

    await order.save();

    const populated = await Order.findById(order._id)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name image price');

    res.json({ success: true, data: populated, message: 'Order cancellation approved successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const rejectCancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    order.status = 'Processing';
    order.cancelRequest = {
      ...order.cancelRequest,
      status: 'Rejected',
      reviewedBy: req.user._id,
      reviewedAt: new Date(),
    };

    await order.save();

    const populated = await Order.findById(order._id)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name image price');

    res.json({ success: true, data: populated, message: 'Order cancellation request rejected.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createOrder,
  getMyOrders,
  getAllOrders,
  getOrderById,
  updateOrderStatus,
  cancelOrder,
  requestCancelOrder,
  getCancelRequests,
  approveCancelOrder,
  rejectCancelOrder,
};
