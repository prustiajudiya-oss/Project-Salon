const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const {
  createOrder,
  getMyOrders,
  getAllOrders,
  getOrderById,
  updateOrderStatus,
  cancelOrder,
  requestCancelOrder,
  getCancelRequests,
  approveCancelOrder,
  rejectCancelOrder,
} = require('../controllers/order.controller');

router.get('/my', protect, getMyOrders);
router.get('/cancellations', protect, authorize('Admin', 'Receptionist'), getCancelRequests);
router.get('/', protect, authorize('Admin', 'Receptionist'), getAllOrders);
router.get('/:id', protect, getOrderById);

router.post(
  '/',
  protect,
  [
    body('items').isArray({ min: 1 }).withMessage('At least one item is required'),
    body('items.*.product').notEmpty().withMessage('Product ID is required'),
    body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  ],
  validate,
  createOrder
);

router.put('/:id/request-cancel', protect, requestCancelOrder);
router.put('/:id/approve-cancel', protect, authorize('Admin', 'Receptionist'), approveCancelOrder);
router.put('/:id/reject-cancel', protect, authorize('Admin', 'Receptionist'), rejectCancelOrder);

router.put('/:id/status', protect, authorize('Admin', 'Receptionist'), updateOrderStatus);
router.put('/:id/cancel', protect, authorize('Admin', 'Receptionist'), cancelOrder);

module.exports = router;
