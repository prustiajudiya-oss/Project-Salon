const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  getAdminDashboard,
  getCustomerDashboard,
  getBarberDashboard,
  getReceptionistDashboard,
} = require('../controllers/dashboard.controller');

const { authorize } = require('../middleware/auth');

// A dashboard is intentionally role-scoped: a signed-in user must never be
// able to request another role's operational data by changing the URL.
router.get('/admin', protect, authorize('Admin'), getAdminDashboard);
router.get('/customer', protect, authorize('Customer'), getCustomerDashboard);
router.get('/barber', protect, authorize('Barber'), getBarberDashboard);
router.get('/receptionist', protect, authorize('Receptionist'), getReceptionistDashboard);

module.exports = router;
