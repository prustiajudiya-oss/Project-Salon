const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./models/User');

dotenv.config();

async function ensureDemoAdmin() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/salon_management');

  const email = 'admin@salon.com';
  let admin = await User.findOne({ email }).select('+password');

  if (!admin) {
    admin = new User({ name: 'Admin User', email, password: 'admin123', role: 'Admin' });
  } else {
    admin.name = admin.name || 'Admin User';
    admin.password = 'admin123';
    admin.role = 'Admin';
    admin.isActive = true;
  }

  await admin.save();
  console.log('Admin account is ready: admin@salon.com / admin123');
  await mongoose.disconnect();
}

ensureDemoAdmin().catch(async (error) => {
  console.error('Could not set up admin account:', error.message);
  await mongoose.disconnect();
  process.exit(1);
});
